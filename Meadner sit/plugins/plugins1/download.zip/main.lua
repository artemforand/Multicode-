local STYLES = {
    ["Светлая бумага"] = {
        bg = "#FEF3C7",
        border = "#F59E0B",
        icon = "#B45309",
        title = "#78350F",
        divider = "#FCD34D",
        text = "#451A03"
    },
    ["Тёмная тема"] = {
        bg = "#1F2937",
        border = "#374151",
        icon = "#60A5FA",
        title = "#F3F4F6",
        divider = "#4B5563",
        text = "#E5E7EB"
    },
    ["Неон"] = {
        bg = "#0F172A",
        border = "#06B6D4",
        icon = "#22D3EE",
        title = "#38BDF8",
        divider = "#0891B2",
        text = "#E0F2FE"
    },
    ["Минимализм"] = {
        bg = "#FFFFFF",
        border = "#E2E8F0",
        icon = "#64748B",
        title = "#0F172A",
        divider = "#E2E8F0",
        text = "#334155"
    }
}

function on_item_reveal(payload)
    if payload.item_json.pluginTypeId == "mnd.custom.notes:note" then
        local title = payload.item_json.pluginData.title or "Заметка"
        local content = payload.item_json.pluginData.content or ""
        local styleName = payload.item_json.pluginData.style or "Светлая бумага"

        local theme = STYLES[styleName] or STYLES["Светлая бумага"]

        mnd.ui.render("item:" .. payload.item_id, {
            type = "card",
            background = theme.bg,
            border = theme.border,
            radius = 8,
            padding = 14,
            gap = 8,
            children = {
                {
                    type = "row",
                    gap = 6,
                    align = "topStart",
                    children = {
                        {
                            type = "icon",
                            name = "note",
                            color = theme.icon,
                            size = 24
                        },
                        {
                            type = "text",
                            text = title,
                            color = theme.title,
                            weight = "bold",
                            maxLines = 3,
                            expand = true
                        }
                    }
                },
                {
                    type = "divider",
                    color = theme.divider,
                    thickness = 1
                },
                {
                    type = "text",
                    text = content,
                    color = theme.text,
                    maxLines = 12
                }
            }
        })
    end
end
